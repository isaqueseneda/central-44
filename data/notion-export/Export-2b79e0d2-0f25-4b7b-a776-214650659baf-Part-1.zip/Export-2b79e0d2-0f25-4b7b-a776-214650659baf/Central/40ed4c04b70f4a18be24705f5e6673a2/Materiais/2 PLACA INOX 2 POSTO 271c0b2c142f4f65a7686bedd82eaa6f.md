# 2 PLACA INOX 2 POSTO

Ordens de Serviço: CATANDUVA (../Ordens%20de%20Servi%C3%A7o/CATANDUVA%20c66f67df67934ff4b8951e32aa1ca450.md)
Compra (unid, m, kg): R$ 22,50
Venda (unid, m, kg): R$ 67,00